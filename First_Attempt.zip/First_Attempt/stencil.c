#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <immintrin.h>
#include "../simple.h"
#include <CL/cl.h>

#define REAL float

struct timespec start, stop;

void printTimeElapsed(char *text)
{
    double elapsed = (stop.tv_sec - start.tv_sec) * 1000.0 + (double)(stop.tv_nsec - start.tv_nsec) / 1000000.0;
    printf("%s: %f msec\n", text, elapsed);
}

void timeDirectImplementation(int count, float *data, float *results)
{
    clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &start);
    for (int i = 0; i < count; i++)
        results[i] = data[i] * data[i];
    clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &stop);
    printTimeElapsed("kernel equivalent on host");
}

const REAL a = 0.1;
const REAL b = 0.2;
const REAL c = 0.3;

void Stencil(REAL **in, REAL **out, size_t n, int iterations)
{
    (*out)[0] = (*in)[0];
    (*out)[n - 1] = (*in)[n - 1];

    for (int t = 1; t <= iterations; t++)
    {
        /* Update only the inner values. */
        for (int i = 1; i < n - 1; i++)
        {
            (*out)[i] = a * (*in)[i - 1] +
                        b * (*in)[i] +
                        c * (*in)[i + 1];
        }

        /* The output of this iteration is the input of the next iteration (if there is one). */
        if (t != iterations)
        {
            REAL *temp = *in;
            *in = *out;
            *out = temp;
        }
    }
}

int main(int argc, char **argv)
{
    if (argc != 4)
    {
        printf("Please specify 3 arguments (n, iterations, workgroupsize).\n");
        return EXIT_FAILURE;
    }

    //dimension 1
    size_t global[1];
    size_t local[1];

    size_t n = atoll(argv[1]);
    int iterations = atoi(argv[2]);
    // take the third argument given the size of the workgroup
    local[0] = atoi(argv[3]); //Multiple 32
    //take the fourth argument given the amount of threads
    global[0] = n;

    //in example code done before initGPU()
    clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &start);

    //initializing
    cl_int err = initGPU();

    /* Reading the openCL kernel code from 'stencil.cl' */
    char *KernelSource = readOpenCL("src/opencl/stencil.cl");

    //set up the kernel if init GPU went well
    if (err == CL_SUCCESS)
    {
        REAL *in = calloc(n, sizeof(REAL));
        in[0] = 100;
        in[n - 1] = 1000;
        REAL *out = malloc(n * sizeof(REAL));
        out[0] = in[0];
        out[n - 1] = in[n - 1];

        

        //For loop this
        for (int i = 0; i < iterations; ++i)
        {
            //setup kernel and give arguments
            cl_kernel kernel = setupKernel(KernelSource, "stencil", 3, 
                                            FloatArr, n, in, 
                                            FloatArr, n, out, 
                                            IntConst, n);
            
            //run the kernel
            // printf("HERE11111111111 11111\n");
            runKernel(kernel, 1, global, local);
            err = clReleaseKernel(kernel);

            // Swap the input and output for the next iteration
            REAL *temp = in;
            in = out;
            out = temp;
            err = freeMemory();
        }


        clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &stop);

        printKernelTime();
        printTransferTimes();
        printTimeElapsed("CPU time spent");

        /* Get and print runtime of equivalent run on the host */
        timeDirectImplementation((int)n, in, out);

        free(in);
        free(out);
    }

    
    err = freeDevice();
    

    return EXIT_SUCCESS;
}